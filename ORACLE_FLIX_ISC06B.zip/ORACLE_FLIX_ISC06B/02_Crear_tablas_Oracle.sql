--Creacion de la tabla customer
--Hicimos constraint por tabla
DROP TABLE CUSTOMERS PURGE;
Create table CUSTOMERS(CUSTOMER_ID NUMBER(10) NOT NULL,       
                       LAST_NAME VARCHAR2(25) NOT NULL, --Creamos los constraint de los campos que no deben ser nulos
                       FIRST_NAME VARCHAR2(25)NOT NULL,
                       HOME_PHONE VARCHAR2(12)NOT NULL,
                       ADDRESS VARCHAR2(100) NOT NULL,
                       CITY VARCHAR2(30) NOT NULL,
                       STATES VARCHAR2(2) NOT NULL,
                       EMAIL VARCHAR2(25), --Estos valores pueden o no ser llenados, por eso no se le asigna constraint
                       CELL_PHONE VARCHAR2(12),
                       CONSTRAINT PK_CUSTOMER PRIMARY KEY (CUSTOMER_ID)); --Creamos un constraint para la llave primaria, las claves primarias no pueden repetirse ni ser nulas
                       
select *from user_constraints where table_name='CUSTOMERS'; --Muestra los constrint de la tabla
 
 --CONSTRAINTS A NIVEL DE TABLA
 DROP TABLE MOVIES PURGE;
Create table MOVIES(TITLE_ID NUMBER(10) NOT NULL, 
                    TITLE VARCHAR2(60) NOT NULL,
                    DESCRIPTIONS VARCHAR2(400) NOT NULL,
                    RATING VARCHAR2(4),
                    CATEGORYS VARCHAR2(20),
                    RELEASE_DATE date NOT NULL,
                    CONSTRAINT PK_MOVIES PRIMARY KEY (TITLE_ID),
                    CONSTRAINT CHECK_RATING CHECK (RATING IN ('G', 'PG','R','PG13')) , --con este constrain le decimos que valide que solo se pongan esos raiting
                    CONSTRAINT CHECK_CATEGORY CHECK (CATEGORYS IN ('DRAMA', 'COMEDY', 'ACTION', 'CHILD', 'SCIFI','DOCUMENTARY'))); --con este check decimos que valide que solo se puedan escribir estas categorias
 

select *from user_constraints where table_name='MOVIES'; --Muestra los constrint de la tabla

--CONSTRAINTS A NIVEL DE TABLA
DROP TABLE MEDIA PURGE;
Create table MEDIA(MEDIA_ID NUMBER(10) NOT NULL,
                   FORMATS VARCHAR2(3) NOT NULL,
                   TITLE_ID NUMBER(10) NOT NULL, 
                   CONSTRAINT PK_MEDIA PRIMARY KEY (MEDIA_ID),
                   CONSTRAINT FK_TITLE FOREIGN KEY (TITLE_ID)
                                       REFERENCES MOVIES(TITLE_ID) ON DELETE CASCADE); --con este constraint relacionamos la tabla movies y media y le decimos 
                                                                                              --que si se llega a borrar informaci�n de la tabla principal(MOVIES) tambien
                                                                                              --boore la infromaci�n de esta tabla, sentidmos que el borrar en cascada es mas
                                                                                              --conveniente ya que los datos de esta tabla no tendr�an sentido si no se sabe
                                                                                              --de la MOVIE que se esta hablando
                                                                                              
select *from user_constraints where table_name='MEDIA'; --Muestra los constrint de la tabla   

--CONSTRAINTS A NIVEL DE TABLA
DROP TABLE RENTAL_HISTORY PURGE;

Create table RENTAL_HISTORY(MEDIA_ID NUMBER(10) NOT NULL,
                            RENTAL_DATE DATE DEFAULT SYSDATE NOT NULL,
                            CUSTOMER_ID NUMBER(10) NOT NULL,
                            RETURN_DATE DATE,
                            CONSTRAINT FK_MEDIA FOREIGN KEY (MEDIA_ID)
                                                REFERENCES MEDIA(MEDIA_ID) ON DELETE SET NULL, --En este caso ponemos ON DELETE NULL  ya que consideramos que los datos de esta tabla si se verian seriamente afectados si decidiamos borrarlo en cascada
                            CONSTRAINT FK_CUSTOMER FOREIGN KEY (CUSTOMER_ID)
                                                   REFERENCES CUSTOMERS(CUSTOMER_ID)ON DELETE SET NULL,
                            CONSTRAINT PK_RENTAL PRIMARY KEY (MEDIA_ID, RENTAL_DATE));--LLlave compuesta

select *from user_constraints where table_name='RENTAL_HISTORY'; --Muestra los constrint de la tabla   

--CONSTRAINTS A NIVEL DE TABLA
DROP TABLE ACTORS PURGE;

CREATE TABLE ACTORS(ACTOR_ID NUMBER(10) NOT NULL,
                    STAGE_NAME VARCHAR2(40) NOT NULL,
                    LAST_NAME VARCHAR2(25) NOT NULL,
                    FIRST_NAME VARCHAR2(25) NOT NULL,
                    BIRTH_DATE DATE NOT NULL,
                    CONSTRAINT PK_ACTORS PRIMARY KEY (ACTOR_ID));

select *from user_constraints where table_name='ACTORS'; --Muestra los constrint de la tabla 



--CONSTRAINTS A NIVEL DE TABLA
DROP TABLE STAR_BILLINGS PURGE;
          
CREATE TABLE STAR_BILLINGS(ACTOR_ID NUMBER(10) NOT NULL,
                           TITLE_ID NUMBER(10) NOT NULL,
                           COMMENTS VARCHAR2(40),
                           CONSTRAINT FK_ACTOR FOREIGN KEY (ACTOR_ID)
                                               REFERENCES ACTORS(ACTOR_ID) ON DELETE CASCADE, --Elegimos esta forma de borrar porque sentimdos que si se llega a borrar cualquiera de estos datos pierde sentido la tabla 
                           CONSTRAINT FK_TITLES FOREIGN KEY (TITLE_ID)
                                               REFERENCES MOVIES(TITLE_ID) ON DELETE CASCADE, 
                           CONSTRAINT PK_STAR PRIMARY KEY (ACTOR_ID, TITLE_ID));--LLlave compuesta
                           
select *from user_constraints where table_name='ACTORS'; --Muestra los constrint de la tabla 


                    