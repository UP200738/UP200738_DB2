create database DbPeliculas;
use DbPeliculas;

create table CUSTOMERS
(
	CUSTOMER_ID int(10) auto_increment unique, constraint ct_pk_customer primary key(CUSTOMER_ID),
    LAST_NAME varchar(25) not null,
    FIRST_NAME varchar(25) not null, 
    HOME_PHONE varchar(12) not null, 
    ADDRESS varchar(100) not null,
    CITY varchar(30) not null,
    STATE varchar(2) not null,
    EMAIL varchar(25),
    CELL_PHONE varchar(12)
);
alter table CUSTOMERS auto_increment = 101;
desc CUSTOMERS;

create table MOVIES
(
	TITLE_ID int(10) auto_increment unique, constraint mv_pk_title primary key(TITLE_ID),
    TITLE varchar(60) not null,
	DESCRIPTION_MOVIE varchar(400) not null,
    RATING varchar(4), constraint mv_upcheck_rating check(UPPER(RATING) in ('PG', 'G', 'PG13', 'R')), 
    constraint mv_check_rating check(RATING in ('PG', 'G', 'PG13', 'R')),
    CATEGORY varchar(20), constraint mv_upcheck_cat check(UPPER(CATEGORY) in ('DRAMA', 'COMEDY', 'ACTION', 'CHILD', 'SCIFI', 'DOCUMENTARY')),
    constraint mv_check_cat check(CATEGORY in ('DRAMA', 'COMEDY', 'ACTION', 'CHILD', 'SCIFI', 'DOCUMENTARY')),
    RELEASE_DATE date not null
);
desc MOVIES;

create table MEDIA
(
	MEDIA_ID int(10) auto_increment unique, constraint md_pk_media primary key(MEDIA_ID),
    FORMAT_MEDIA varchar(3) not null,
    TITLE_ID int(10) not null, constraint md_fk_title foreign key(TITLE_ID) references MOVIES(TITLE_ID)
); 
alter table MEDIA auto_increment = 92;
desc MEDIA;

create table RENTAL_HISTORY
(
	MEDIA_ID int(10) auto_increment unique, constraint relhs_fk_media foreign key (MEDIA_ID) references MEDIA(MEDIA_ID),
    RENTAL_DATE date, constraint relhs_pk_rendate primary key (MEDIA_ID, RENTAL_DATE),
    CUSTOMER_ID int(10) not null, constraint relhs_fk_customer foreign key(CUSTOMER_ID) references CUSTOMERS(CUSTOMER_ID),
    RETURN_DATE date
);
desc RENTAL_HISTORY;
 
create table ACTORS
 (
	ACTOR_ID int(10) auto_increment unique, constraint act_pk_actor primary key(ACTOR_ID),
    STAGE_NAME varchar(40) not null,
    FIRST_NAME varchar(25) not null,
    LAST_NAME varchar(25) not null,
    BIRTH_DATE date not null
 );
alter table ACTORS auto_increment = 1001; 
desc ACTORS;

create table STAR_BILLINGS
(
	ACTOR_ID int(10) not null, constraint stbill_fk_actor foreign key (ACTOR_ID) references ACTORS(ACTOR_ID),
    TITLE_ID int(10) not null, constraint stbill_fk_title foreign key (TITLE_ID) references MOVIES(TITLE_ID),
    COMMENTS varchar(40),
    constraint stbill_pk_actor_title primary key (ACTOR_ID, TITLE_ID)
);
desc STAR_BILLINGS;

select * from CUSTOMERS;
select * from MEDIA;
select * from ACTORS;
select * from MOVIES;



