--Creacion de la tabla customer
--Hicimos constraint por tabla
DROP TABLE CUSTOMERS PURGE;
Create table CUSTOMERS(CUSTOMER_ID NUMBER(10) NOT NULL,       
                       LAST_NAME VARCHAR2(25) NOT NULL, --Creamos los constraint de los campos que no deben ser nulos
                       FIRST_NAME VARCHAR2(25)NOT NULL,
                       HOME_PHONE VARCHAR2(12)NOT NULL,
                       ADDRESS VARCHAR2(100) NOT NULL,
                       CITY VARCHAR2(30) NOT NULL,
                       STATES VARCHAR2(2) NOT NULL,
                       EMAIL VARCHAR2(25), --Estos valores pueden o no ser llenados, por eso no se le asigna constraint
                       CELL_PHONE VARCHAR2(12),
                       CONSTRAINT PK_CUSTOMER PRIMARY KEY (CUSTOMER_ID)); --Creamos un constraint para la llave primaria, las claves primarias no pueden repetirse ni ser nulas
                       
select *from user_constraints where table_name='CUSTOMERS'; --Muestra los constrint de la tabla
 
 --CONSTRAINTS A NIVEL DE TABLA
 DROP TABLE MOVIES PURGE;
Create table MOVIES(TITLE_ID NUMBER(10) NOT NULL, 
                    TITLE VARCHAR2(60) NOT NULL,
                    DESCRIPTIONS VARCHAR2(400) NOT NULL,
                    RATING VARCHAR2(4),
                    CATEGORYS VARCHAR2(20),
                    RELEASE_DATE date NOT NULL,
                    CONSTRAINT PK_MOVIES PRIMARY KEY (TITLE_ID),
                    CONSTRAINT CHECK_RATING CHECK (RATING IN ('G', 'PG','R','PG13')) , --con este constrain le decimos que valide que solo se pongan esos raiting
                    CONSTRAINT CHECK_CATEGORY CHECK (CATEGORYS IN ('DRAMA', 'COMEDY', 'ACTION', 'CHILD', 'SCIFI','DOCUMENTARY'))); --con este check decimos que valide que solo se puedan escribir estas categorias
 

select *from user_constraints where table_name='MOVIES'; --Muestra los constrint de la tabla

--CONSTRAINTS A NIVEL DE TABLA
DROP TABLE MEDIA PURGE;
Create table MEDIA(MEDIA_ID NUMBER(10) NOT NULL,
                   FORMATS VARCHAR2(3) NOT NULL,
                   TITLE_ID NUMBER(10) NOT NULL, 
                   CONSTRAINT PK_MEDIA PRIMARY KEY (MEDIA_ID),
                   CONSTRAINT FK_TITLE FOREIGN KEY (TITLE_ID)
                                       REFERENCES MOVIES(TITLE_ID) ON DELETE CASCADE); --con este constraint relacionamos la tabla movies y media y le decimos 
                                                                                              --que si se llega a borrar informaci�n de la tabla principal(MOVIES) tambien
                                                                                              --boore la infromaci�n de esta tabla, sentidmos que el borrar en cascada es mas
                                                                                              --conveniente ya que los datos de esta tabla no tendr�an sentido si no se sabe
                                                                                              --de la MOVIE que se esta hablando
                                                                                              
select *from user_constraints where table_name='MEDIA'; --Muestra los constrint de la tabla   

--CONSTRAINTS A NIVEL DE TABLA
DROP TABLE RENTAL_HISTORY PURGE;

Create table RENTAL_HISTORY(MEDIA_ID NUMBER(10) NOT NULL,
                            RENTAL_DATE DATE DEFAULT SYSDATE NOT NULL,
                            CUSTOMER_ID NUMBER(10) NOT NULL,
                            RETURN_DATE DATE,
                            CONSTRAINT FK_MEDIA FOREIGN KEY (MEDIA_ID)
                                                REFERENCES MEDIA(MEDIA_ID) ON DELETE SET NULL, --En este caso ponemos ON DELETE NULL  ya que consideramos que los datos de esta tabla si se verian seriamente afectados si decidiamos borrarlo en cascada
                            CONSTRAINT FK_CUSTOMER FOREIGN KEY (CUSTOMER_ID)
                                                   REFERENCES CUSTOMERS(CUSTOMER_ID)ON DELETE SET NULL,
                            CONSTRAINT PK_RENTAL PRIMARY KEY (MEDIA_ID, RENTAL_DATE));--LLlave compuesta

select *from user_constraints where table_name='RENTAL_HISTORY'; --Muestra los constrint de la tabla   

--CONSTRAINTS A NIVEL DE TABLA
DROP TABLE ACTORS PURGE;

CREATE TABLE ACTORS(ACTOR_ID NUMBER(10) NOT NULL,
                    STAGE_NAME VARCHAR2(40) NOT NULL,
                    LAST_NAME VARCHAR2(25) NOT NULL,
                    FIRST_NAME VARCHAR2(25) NOT NULL,
                    BIRTH_DATE DATE NOT NULL,
                    CONSTRAINT PK_ACTORS PRIMARY KEY (ACTOR_ID));

select *from user_constraints where table_name='ACTORS'; --Muestra los constrint de la tabla 



--CONSTRAINTS A NIVEL DE TABLA
DROP TABLE STAR_BILLINGS PURGE;
          
CREATE TABLE STAR_BILLINGS(ACTOR_ID NUMBER(10) NOT NULL,
                           TITLE_ID NUMBER(10) NOT NULL,
                           COMMENTS VARCHAR2(40),
                           CONSTRAINT FK_ACTOR FOREIGN KEY (ACTOR_ID)
                                               REFERENCES ACTORS(ACTOR_ID) ON DELETE CASCADE, --Elegimos esta forma de borrar porque sentimdos que si se llega a borrar cualquiera de estos datos pierde sentido la tabla 
                           CONSTRAINT FK_TITLES FOREIGN KEY (TITLE_ID)
                                               REFERENCES MOVIES(TITLE_ID) ON DELETE CASCADE, 
                           CONSTRAINT PK_STAR PRIMARY KEY (ACTOR_ID, TITLE_ID));--LLlave compuesta
                           
select *from user_constraints where table_name='ACTORS'; --Muestra los constrint de la tabla 



---CREAR VISTAS. SI NO EXISTE, CREARLAS, SI SI EXISTEN, REMPLAZARLAS. 
CREATE OR REPLACE VIEW TITLE_UNAVAIL AS
SELECT M.TITLE TITLE, S.MEDIA_ID "MEDIA"
FROM MEDIA S INNER JOIN MOVIES M ON M.TITLE_ID = S.TITLE_ID
                INNER JOIN RENTAL_HISTORY R ON S.MEDIA_ID = R.MEDIA_ID
WHERE R.RETURN_DATE IS NULL WITH READ ONLY;
--Sequences
CREATE SEQUENCE customer_id_seq
 INCREMENT BY 1
 START WITH 101
 MAXVALUE 50000
 NOCACHE
 NOCYCLE;
 --drop sequence title_id_seq;
 CREATE SEQUENCE title_id_seq
 INCREMENT BY 1
 START WITH 1
 MAXVALUE 50000
 NOCACHE
 NOCYCLE;
 CREATE SEQUENCE media_id_seq
 INCREMENT BY 1
 START WITH 92
 MAXVALUE 50000
 NOCACHE
 NOCYCLE;
 CREATE SEQUENCE actor_id_seq
 INCREMENT BY 1
 START WITH 1001
 MAXVALUE 50000
 NOCACHE
 NOCYCLE;
 --Datos
 --Customers
 insert into customers(customer_id,last_name,first_name,home_phone,address,city,states,email,cell_phone)
 VALUES(customer_id_seq.nextval,'Palombo', 'Lisa', '716-270-2669', '123 Main St', 'Buffalo', 'NY', 'palombo@ecc.edu', '716-555-1212');
 insert into customers(customer_id,last_name,first_name,home_phone,address,city,states,email,cell_phone)
 VALUES(customer_id_seq.nextval,'Olaya', 'Mascarenas', '605-692-1611', '125 Main St', 'Albania', 'AL', 'olamas@ecc.edu','605-692-1611' );
 insert into customers(customer_id,last_name,first_name,home_phone,address,city,states,email,cell_phone)
 VALUES(customer_id_seq.nextval,'Frank', 'Peterson', '716-605-1611', '126 Main St', 'Macedonia', 'NY', 'franpet@ecc.edu', '716-605-1611');
insert into customers(customer_id,last_name,first_name,home_phone,address,city,states,email,cell_phone)
 VALUES(customer_id_seq.nextval,'Miranda', 'Lisa', '725-161-2669', '127 Main St', 'Mexico', 'IN', 'miranli@ecc.edu', '768-270-213');
 insert into customers(customer_id,last_name,first_name,home_phone,address,city,states,email,cell_phone)
 VALUES(customer_id_seq.nextval,'Olga', 'Pineda', '768-270-213', '128 Main St', 'Inglaterra', 'AN', 'olgapi@ecc.edu', '716-555-1212');
 insert into customers(customer_id,last_name,first_name,home_phone,address,city,states,email,cell_phone)
 VALUES(customer_id_seq.nextval,'Paloma', 'Gisa', '243-343-3417', '129 Main St', 'Explorer', 'IR', 'palogi@ecc.edu', '243-343-3417');
 --Movies
INSERT INTO movies(title_id, title , descriptions ,  rating , categorys , release_date )
VALUES(title_id_seq.nextval, 'Fight Club', 'An insomniac office worker, looking for a way to change his life, crosses paths with a devil-may-care soap maker, forming an underground fight club that evolves into something much, much more.', 'R', 'DRAMA',  TO_DATE('15-OCT-1999','DD-Mon-YYYY'));
INSERT INTO movies(title_id, title , descriptions ,  rating , categorys , release_date )
VALUES(title_id_seq.nextval, 'Neon Genesis Evangelion', 'After the defeat of the final Angel, Shinji Ikari falls into a deep depression.', 'R', 'CHILD',TO_DATE('19-JUL-1997','DD-Mon-YYYY'));
INSERT INTO movies(title_id, title , descriptions ,  rating , categorys , release_date )
VALUES(title_id_seq.nextval, 'Evangelion 1.01 You are (not) Alone','Young Shinji Ikari arrives in Tokyo-3, a city rebuilt after a cataclysmic event called Second Impact that shed the world of half the human population, to meet and work for his estranged father.', 'R', 'SCIFI',TO_DATE('1-SEP-2007','DD-Mon-YYYY'));
INSERT INTO movies(title_id, title , descriptions ,  rating , categorys , release_date )
VALUES(title_id_seq.nextval,'Evangelion 2.0 You Can (Not) Advance', 'Under constant attack by Angels, NERV introduces two new pilots: the mysterious Makinami Mari Illustrous and the intense Asuka Langley Shikinami.', 'PG', 'DRAMA',TO_DATE('27-JUN-2009','DD-Mon-YYYY'));
INSERT INTO movies(title_id, title , descriptions ,  rating , categorys , release_date )
VALUES(title_id_seq.nextval, 'AKIRA', 'A secret military project endangers Neo-Tokyo when it turns a biker gang member into a rampaging psychic psychopath who can only be stopped by a teenager, his gang of biker friends and a group of psychics.', 'R', 'DOCUMENTARY',TO_DATE('16-JUL-1988','DD-Mon-YYYY'));
INSERT INTO movies(title_id, title , descriptions ,  rating , categorys , release_date )
VALUES(title_id_seq.nextval, 'Cowboy Bebop', 'The futuristic misadventures and tragedies of a bounty hunter and his companions.', 'R', 'CHILD',TO_DATE('3-ABR-1998','DD-Mon-YYYY'));
--MEDIA
INSERT INTO media(media_id, formats , title_id)
VALUES(media_id_seq.nextval,'DVD',1);
INSERT INTO media(media_id, formats , title_id)
VALUES(media_id_seq.nextval,'DVD',1);
INSERT INTO media(media_id, formats , title_id)
VALUES(media_id_seq.nextval,'VHS',2);
INSERT INTO media(media_id, formats , title_id)
VALUES(media_id_seq.nextval,'VHS',2);
INSERT INTO media(media_id, formats , title_id)
VALUES(media_id_seq.nextval,'VHS',3);
INSERT INTO media(media_id, formats , title_id)
VALUES(media_id_seq.nextval,'DVD',3);
INSERT INTO media(media_id, formats , title_id)
VALUES(media_id_seq.nextval,'VHS',4);
INSERT INTO media(media_id, formats , title_id)
VALUES(media_id_seq.nextval,'DVD',4);
INSERT INTO media(media_id, formats , title_id)
VALUES(media_id_seq.nextval,'VHS',5);
INSERT INTO media(media_id, formats , title_id)
VALUES(media_id_seq.nextval,'DVD',5);
INSERT INTO media(media_id, formats , title_id)
VALUES(media_id_seq.nextval,'VHS',6);
INSERT INTO media(media_id, formats , title_id)
VALUES(media_id_seq.nextval,'DVD',6);
--Actors
INSERT INTO actors(actor_id, stage_name, first_name, last_name, birth_date)
VALUES(actor_id_seq.NEXTVAL, 'Brad Pitt', 'William', 'Pitt', TO_DATE('18-DIC-1963','DD-Mon-YYYY'));
INSERT INTO actors(actor_id, stage_name, first_name, last_name, birth_date)
VALUES(actor_id_seq.NEXTVAL,'Johnny Deep', 'John', 'Deep',TO_DATE('9-JUN-1963','DD-Mon-YYYY'));
INSERT INTO actors(actor_id, stage_name, first_name, last_name, birth_date)
VALUES(actor_id_seq.NEXTVAL,'Leonardo DiCaprio', 'Leonardo', 'DiCaprio',TO_DATE('1-MAR-1955','DD-Mon-YYYY'));
INSERT INTO actors(actor_id, stage_name, first_name, last_name, birth_date)
VALUES(actor_id_seq.NEXTVAL,'Bruce Willis', 'Walter', 'Willis',TO_DATE('17-DIC-1977','DD-Mon-YYYY'));
--INDEX
create index customer_last_name_idx on customers(last_name);
select * from user_indexes
where index_name='CUSTOMER_LAST_NAME_IDX';
--synonym
create or replace synonym tu for title_unavail;
select *from user_synonyms
where synonym_name='TU';
                    