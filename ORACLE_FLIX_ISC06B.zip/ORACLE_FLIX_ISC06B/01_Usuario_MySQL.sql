CREATE DATABASE IF NOT EXISTS FLIX;

drop user 'FLIX'@'localhost';
CREATE USER 'FLIX'@'localhost' IDENTIFIED BY 'password';
GRANT SELECT, INSERT, UPDATE, DELETE, CREATE, CREATE VIEW, INDEX, REFERENCES
      ON flix.*
     TO 'FLIX'@'localhost';
     
/*En esta ocasión estamos indicando que el nuevo usuario podrá consultar, crear, actualizar y eliminar registros, así cómo podrá crear o eliminar elementos (tablas, índices, columnas, funciones, stores, etc ...).
Todos estos permisos serán válidos únicamente en la base de datos FLIX y se aplicarán a todas las tablas.*/
