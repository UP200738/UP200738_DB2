--Crea usuario y contraseña ORACLE
Alter session set "_oracle_script"=true;  --indica a Oracle que lo que va a ejecutarse a continuación es un script oficial y, por lo tanto, puede "saltarse" un poco las reglas de nomenclatura para objetos, usuarios, etc. así como ciertas comprobaciones en nombres, etc.

drop user FLIX;
drop user ORACLE_FLIX;


Create user FLIX  --nombre del usuario
identified by password --contraseña
default tablespace users --Asigna a un usuario el tablespace por defecto para almacenar los objetos que cree
temporary tablespace temp --Los segmentos temporales son objetos que se crean dinámicamente en la base de datos y que almacenan datos durante las operaciones de ordenación de gran tamaño (SELECT, DISTINCT,UNION y CREATE INDEX)
quota unlimited on users; --Asigna un espacio en megabites o kilobites en el tablespace asignado. Si no se especifica esta cláusula

--Otorgar privilegios de sistema
GRANT create session,    --Para iniciar sesion
      create table,      --Para crear tabla
      create sequence,   --Para crear secuencias
      create view        --Para crear vistas
      TO FLIX;

--Otorgar privilegios de objeto
grant create any index to FLIX; --Para crear index
grant delete any table to FLIX;
grant insert any table to FLIX; --Para insertar datos
grant select any table to FLIX; --Para hacer select, consultas
grant create SYNONYM to FLIX;
grant update any table to FLIX;