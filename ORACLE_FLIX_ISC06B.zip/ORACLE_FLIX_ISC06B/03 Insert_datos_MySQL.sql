create database DbPeliculas;
use DbPeliculas;

create table CUSTOMERS
(
	CUSTOMER_ID int(10) auto_increment unique, constraint ct_pk_customer primary key(CUSTOMER_ID),
    LAST_NAME varchar(25) not null,
    FIRST_NAME varchar(25) not null, 
    HOME_PHONE varchar(12) not null, 
    ADDRESS varchar(100) not null,
    CITY varchar(30) not null,
    STATE varchar(2) not null,
    EMAIL varchar(25),
    CELL_PHONE varchar(12)
);
alter table CUSTOMERS auto_increment = 101;
desc CUSTOMERS;

create table MOVIES
(
	TITLE_ID int(10) auto_increment unique, constraint mv_pk_title primary key(TITLE_ID),
    TITLE varchar(60) not null,
	DESCRIPTION_MOVIE varchar(400) not null,
    RATING varchar(4), constraint mv_upcheck_rating check(UPPER(RATING) in ('PG', 'G', 'PG13', 'R')), 
    constraint mv_check_rating check(RATING in ('PG', 'G', 'PG13', 'R')),
    CATEGORY varchar(20), constraint mv_upcheck_cat check(UPPER(CATEGORY) in ('DRAMA', 'COMEDY', 'ACTION', 'CHILD', 'SCIFI', 'DOCUMENTARY')),
    constraint mv_check_cat check(CATEGORY in ('DRAMA', 'COMEDY', 'ACTION', 'CHILD', 'SCIFI', 'DOCUMENTARY')),
    RELEASE_DATE date not null
);
desc MOVIES;

create table MEDIA
(
	MEDIA_ID int(10) auto_increment unique, constraint md_pk_media primary key(MEDIA_ID),
    FORMAT_MEDIA varchar(3) not null,
    TITLE_ID int(10) not null, constraint md_fk_title foreign key(TITLE_ID) references MOVIES(TITLE_ID)
); 
alter table MEDIA auto_increment = 92;
desc MEDIA;

create table RENTAL_HISTORY
(
	MEDIA_ID int(10) auto_increment unique, constraint relhs_fk_media foreign key (MEDIA_ID) references MEDIA(MEDIA_ID),
    RENTAL_DATE date, constraint relhs_pk_rendate primary key (MEDIA_ID, RENTAL_DATE),
    CUSTOMER_ID int(10) not null, constraint relhs_fk_customer foreign key(CUSTOMER_ID) references CUSTOMERS(CUSTOMER_ID),
    RETURN_DATE date
);
desc RENTAL_HISTORY;
 
create table ACTORS
 (
	ACTOR_ID int(10) auto_increment unique, constraint act_pk_actor primary key(ACTOR_ID),
    STAGE_NAME varchar(40) not null,
    FIRST_NAME varchar(25) not null,
    LAST_NAME varchar(25) not null,
    BIRTH_DATE date not null
 );
alter table ACTORS auto_increment = 1001; 
desc ACTORS;

create table STAR_BILLINGS
(
	ACTOR_ID int(10) not null, constraint stbill_fk_actor foreign key (ACTOR_ID) references ACTORS(ACTOR_ID),
    TITLE_ID int(10) not null, constraint stbill_fk_title foreign key (TITLE_ID) references MOVIES(TITLE_ID),
    COMMENTS varchar(40),
    constraint stbill_pk_actor_title primary key (ACTOR_ID, TITLE_ID)
);
desc STAR_BILLINGS;
create view
TITLE_UNAVAIL as
select media_id,title from media inner join movies ; 

CREATE OR REPLACE VIEW TITLE_UNAVAIL AS
SELECT M.TITLE TITLE, S.MEDIA_ID "MEDIA"
FROM MEDIA S INNER JOIN MOVIES M ON M.TITLE_ID = S.TITLE_ID
                INNER JOIN RENTAL_HISTORY R ON S.MEDIA_ID = R.MEDIA_ID 
WHERE R.RETURN_DATE IS NULL;

insert into CUSTOMERS(LAST_NAME, FIRST_NAME,  HOME_PHONE, ADDRESS, CITY, STATE, EMAIL, CELL_PHONE)
values('Palombo', 'Lisa', '716-270-2669', '123 Main St', 'Buffalo', 'NY', 'palombo@ecc.edu', '716-555-1212'),
('Olaya', 'Mascarenas', '605-692-1611', '125 Main St', 'Albania', 'AL', 'olamas@ecc.edu','605-692-1611' ),
('Frank', 'Peterson', '716-605-1611', '126 Main St', 'Macedonia', 'NY', 'franpet@ecc.edu', '716-605-1611'),
('Miranda', 'Lisa', '725-161-2669', '127 Main St', 'Mexico', 'IN', 'miranli@ecc.edu', '768-270-213'),
('Olga', 'Pineda', '768-270-213', '128 Main St', 'Inglaterra', 'AN', 'olgapi@ecc.edu', '716-555-1212'),
('Paloma', 'Gisa', '243-343-3417', '129 Main St', 'Explorer', 'IR', 'palogi@ecc.edu', '243-343-3417');
select * from CUSTOMERS;

insert into MOVIES(TITLE, DESCRIPTION_MOVIE,  RATING, CATEGORY, RELEASE_DATE)
values('Fight Club', 'An insomniac office worker, looking for a way to change his life, crosses paths with a devil-may-care soap maker, forming an underground fight club that evolves into something much, much more.', 'R', 'DRAMA',  STR_TO_DATE("15 October 1999","%d %M %Y")),
('Neon Genesis Evangelion', 'After the defeat of the final Angel, Shinji Ikari falls into a deep depression. ', 'R', 'CHILD',  STR_TO_DATE("19 July 1997","%d %M %Y")),
('Evangelion 1.01 You are (not) Alone','Young Shinji Ikari arrives in Tokyo-3, a city rebuilt after a cataclysmic event called Second Impact that shed the world of half the human population, to meet and work for his estranged father.', 'R', 'SCIFI',  STR_TO_DATE("1 September 2007","%d %M %Y")),
('Evangelion 2.0 You Can (Not) Advance', 'Under constant attack by Angels, NERV introduces two new pilots: the mysterious Makinami Mari Illustrous and the intense Asuka Langley Shikinami.', 'PG', 'DRAMA',  STR_TO_DATE("27 June 2009","%d %M %Y")),
('AKIRA', 'A secret military project endangers Neo-Tokyo when it turns a biker gang member into a rampaging psychic psychopath who can only be stopped by a teenager, his gang of biker friends and a group of psychics.', 'r', 'DOCUMENTARY',  STR_TO_DATE("16 July 1988","%d %M %Y")),
('Cowboy Bebop', 'The futuristic misadventures and tragedies of a bounty hunter and his companions.', 'R', 'CHILD',  STR_TO_DATE("3 April 1998","%d %M %Y"));
select * from MOVIES;
 
insert into MEDIA(FORMAT_MEDIA, TITLE_ID)
values ('DVD',1),
('DVD',1),
('VHS',2),
('VHS',2),
('VHS',3),
('DVD',3),
('VHS',4),
('DVD',4),
('VHS',5),
('DVD',5),
('VHS',6),
('DVD',6);
select * from MEDIA;

insert into ACTORS(STAGE_NAME, FIRST_NAME, LAST_NAME, BIRTH_DATE)
values ('Brad Pitt', 'William', 'Pitt', STR_TO_DATE("18 DEC 1963","%d %M %Y")),
('Johnny Deep', 'John', 'Deep', STR_TO_DATE("9 June 1963","%d %M %Y")),
('Leonardo DiCaprio', 'Leonardo', 'DiCaprio', STR_TO_DATE("1 MARCH 1955","%d %M %Y")),
('Bruce Willis', 'Walter', 'Willis', STR_TO_DATE("17 DEC 1977","%d %M %Y"));
select * from ACTORS;

create index INDEX_CUSTOM
on CUSTOMERS(LAST_NAME);
 
select * from CUSTOMERS;
select * from MEDIA;
select * from ACTORS;
select * from MOVIES;



